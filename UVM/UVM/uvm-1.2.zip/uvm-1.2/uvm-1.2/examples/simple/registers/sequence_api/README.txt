// This example uses the reg/mem write/read convenience API in the
// user register sequence (blk_seqlib.sv). The convenience methods
// provide the ~parent~ argument for you when calling the corresponding
// method in the register or memory. Compare this example's blk_seqlib.sv
// file with that in the ~vertical_reuse~ example.


